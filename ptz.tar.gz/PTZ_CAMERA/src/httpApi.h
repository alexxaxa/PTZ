#ifndef HTTPAPI
#define HTTPAPI

#include <curl/curl.h>
#include <string>
#include <stdio.h>

const std::string prefixPTZ = "http://192.168.91.241";


class httpApi
{
public:
    // Constructor & destructor
    httpApi();
virtual   ~httpApi();
	bool sendHttpGet(const std::string &url, FILE *fp = NULL);
	
private:	
static size_t writeFpCallback(char *ptr, size_t size, size_t nmemb, FILE *stream);
static size_t writeMemoryCallback(char *ptr, size_t size, size_t nmemb,std::string *data);
	CURLcode httpGet(const std::string &url, FILE *fp);
	CURL *curl_;

};

class httpApiMult
{
public:
    // Constructor & destructor
    httpApiMult();
virtual   ~httpApiMult();
	CURLcode httpGet(const std::string &url, FILE *fp);
	
private:	
static size_t writeFpCallback(char *ptr, size_t size, size_t nmemb, FILE *stream);
	CURLM *curlMulti_;
    CURL *curlMultiEasy_;

};

#endif