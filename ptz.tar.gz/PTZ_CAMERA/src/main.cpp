
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sstream>
#include <iostream>
#include <unistd.h>
#include <curl/curl.h>

#include "httpApi.h"
#include "thread_2.h"
#include "thread_3.h"


enum {TIMEOUT_MC = 2000000};
	



int main(int argc, char *argv[])
{
    // Установка обработчиков системных сигналов
	
	
	std::string url;
	int goPTZ_15_1000 = 15*1000/180;
	int goPTZ_10_1000 = 10*1000/180;
	int goPTZ_55_1000 = 55*1000/180;
	
    if (argc == 2) {
        if (std::string(argv[1]) == "-v" || std::string(argv[1]) == "--version") {
            std::cout << "cameraPTZ. " << "v.1.1.1" << std::endl;
            return 0;
        }
	}	
	
	std::cout << "start cameraPTZ" << std::endl;

	
	curl_global_init(CURL_GLOBAL_ALL);		//инициализация библиотеки CURL
	httpApi * httpPTZ = new httpApi();
	poster * posterPTZ = new poster();
	saveVideo * savePTZ = new saveVideo(std::string(argv[1]));
	while(true) 
	{
		//PTZ по центру с минимальным зумом
		url = prefixPTZ + "/cgi-bin/ptz.cgi?action=moveAbsolutely&channel=1&arg1=0&arg2=0&arg3=0";
		if(!httpPTZ->sendHttpGet(url)) break;
		std::cout << "posterNow ---->" << std::endl;
		posterPTZ->posterNow("./Snapshot1", "1center|center");
		usleep(TIMEOUT_MC);

		//поворачивает на лево и вверх (допустим на 15’) делает zoom + 5 (процентов)
		url = prefixPTZ + "/cgi-bin/ptz.cgi?action=moveAbsolutely&channel=1&arg1=0.0" + std::to_string(goPTZ_15_1000) + "&arg2=-0.0" + std::to_string(goPTZ_15_1000) + "&arg3=0.05";
		if(!httpPTZ->sendHttpGet(url)) break;
		posterPTZ->posterNow("./Snapshot2", "2left|up");
		usleep(TIMEOUT_MC);
		
		//поворачивает на право и вниз (допустим на 10’) делает zoom + 10
		url = prefixPTZ + "/cgi-bin/ptz.cgi?action=moveRelatively&channel=1&arg1=0.0" + std::to_string(goPTZ_10_1000) + "&arg2=-0.0" + std::to_string(goPTZ_10_1000) + "&arg3=0.1";
		if(!httpPTZ->sendHttpGet(url)) break;
		posterPTZ->posterNow("./Snapshot3", "3right|down");
		usleep(TIMEOUT_MC);
		
		//поворачивает на лево и вниз (допустим на 55) делает zoom - 15
		url = prefixPTZ + "/cgi-bin/ptz.cgi?action=moveRelatively&channel=1&arg1=-0.0" + std::to_string(goPTZ_55_1000) + "&arg2=-0.0" + std::to_string(goPTZ_55_1000) + "&arg3=-0.15";
		if(!httpPTZ->sendHttpGet(url)) break;
		posterPTZ->posterNow("./Snapshot4", "4left|down");
		usleep(TIMEOUT_MC);
		
		//поворачивает на лево (допустим на 55) делает zoom + 20
		url = prefixPTZ + "/cgi-bin/ptz.cgi?action=moveRelatively&channel=1&arg1=-0.0" + std::to_string(goPTZ_55_1000) + "&arg2=0&arg3=0.2";
		if(!httpPTZ->sendHttpGet(url)) break;
		posterPTZ->posterNow("./Snapshot5", "5left|.");
		usleep(TIMEOUT_MC);
		break;
	}
	delete posterPTZ;
	delete httpPTZ;
	delete savePTZ;
	curl_global_cleanup();
	return 0;
}




class initBasket2;