#ifndef TH_2
#define TH_2

#include <string>
#include <thread>
#include <mutex>

#include "httpApi.h"


class saveVideo
{
public:
    // Constructor & destructor
    saveVideo(std::string);
    ~saveVideo();
		
private:	
	std::thread thr;
	void worker();
	httpApiMult httpSave;
	bool obmanka(bool);
	std::string name;
	FILE *fp;
	bool run;
};


#endif