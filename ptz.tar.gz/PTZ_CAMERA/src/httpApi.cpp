
#include "httpApi.h"
#include <unistd.h>
#include <sstream>
#include <iostream>

enum {CONNECTTIMEOUT = 1};
enum {LOW_SPEED_TIME = 10};
enum {LIM_SEND = 3};


const std::string user = "admin";
const std::string password = "admin777";


httpApi::httpApi()
{
	curl_ = curl_easy_init();
}

httpApi::~httpApi()
{
	curl_easy_cleanup(curl_);
}

//static
size_t httpApi::writeMemoryCallback(char *ptr, size_t size, size_t nmemb,std::string *data) 
{
    data->append(ptr);
    return size * nmemb;
}
size_t httpApi::writeFpCallback(char *ptr, size_t size, size_t nmemb, FILE *stream) 
{
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}



CURLcode httpApi::httpGet(const std::string &url, FILE *fp)
{
    CURLcode res;
    curl_easy_reset(curl_);
	std::string response = "";
    curl_easy_setopt(curl_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl_, CURLOPT_FOLLOWLOCATION, 1L);
	curl_easy_setopt(curl_, CURLOPT_USERNAME, "admin");//user.c_str());
    curl_easy_setopt(curl_, CURLOPT_PASSWORD, "admin777");//password.c_str());
	curl_easy_setopt(curl_, CURLOPT_HTTPAUTH, (long)CURLAUTH_DIGEST);
	if(fp == NULL)
	{
    	curl_easy_setopt(curl_, CURLOPT_WRITEFUNCTION, writeMemoryCallback);
		curl_easy_setopt(curl_, CURLOPT_WRITEDATA, (void *)&response);
	}
	else
	{
		curl_easy_setopt(curl_, CURLOPT_WRITEFUNCTION, writeFpCallback);
		curl_easy_setopt(curl_, CURLOPT_WRITEDATA, fp);
	}

    curl_easy_setopt(curl_, CURLOPT_CONNECTTIMEOUT, CONNECTTIMEOUT);
    curl_easy_setopt(curl_, CURLOPT_LOW_SPEED_TIME, LOW_SPEED_TIME);
    curl_easy_setopt(curl_, CURLOPT_LOW_SPEED_LIMIT, 128);
	curl_easy_setopt(curl_, CURLOPT_HTTPGET, 1L);
	curl_easy_setopt(curl_, CURLOPT_NOPROGRESS, 1L);

    res = curl_easy_perform(curl_);
	
    return res;
}

bool httpApi::sendHttpGet(const std::string &url, FILE *fp)
{
	int howSend = LIM_SEND;
	while(--howSend)
	{
		if(httpGet(url, fp) == CURLE_OK)
		{
			return true;	
		}
		std::cout << "can`t send command: " << url << std::endl;
		usleep(500000);
	}
	return false;
}


///////////////////////////
httpApiMult::httpApiMult()
{
	curlMulti_ = curl_multi_init();
	curlMultiEasy_ = curl_easy_init();
}

httpApiMult::~httpApiMult()
{
	if (curlMulti_) 
	{
        if (curlMultiEasy_)
            curl_multi_remove_handle(curlMulti_, curlMultiEasy_);
        curl_multi_cleanup(curlMulti_);
    }

    if (curlMultiEasy_)
        curl_easy_cleanup(curlMultiEasy_);
}

//static

size_t httpApiMult::writeFpCallback(char *ptr, size_t size, size_t nmemb, FILE *stream) 
{
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}



CURLcode httpApiMult::httpGet(const std::string &url, FILE *fp)
{
    CURLcode res;
	std::cout << "csend command save file: " << url << std::endl;
    curl_multi_remove_handle(curlMulti_, curlMultiEasy_);
	std::string response = "";
	curl_easy_reset(curlMultiEasy_);
    curl_easy_setopt(curlMultiEasy_, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curlMultiEasy_, CURLOPT_FOLLOWLOCATION, 1L);
	curl_easy_setopt(curlMultiEasy_, CURLOPT_USERNAME, "admin");//user.c_str());
    curl_easy_setopt(curlMultiEasy_, CURLOPT_PASSWORD, "admin777");//password.c_str());
	curl_easy_setopt(curlMultiEasy_, CURLOPT_HTTPAUTH, (long)CURLAUTH_DIGEST);

	{
		curl_easy_setopt(curlMultiEasy_, CURLOPT_WRITEFUNCTION, writeFpCallback);
		curl_easy_setopt(curlMultiEasy_, CURLOPT_WRITEDATA, fp);
	}

    curl_easy_setopt(curlMultiEasy_, CURLOPT_CONNECTTIMEOUT, CONNECTTIMEOUT);
    curl_easy_setopt(curlMultiEasy_, CURLOPT_LOW_SPEED_TIME, LOW_SPEED_TIME);
    curl_easy_setopt(curlMultiEasy_, CURLOPT_LOW_SPEED_LIMIT, 128);
	curl_easy_setopt(curlMultiEasy_, CURLOPT_HTTPGET, 1L);
	curl_easy_setopt(curlMultiEasy_, CURLOPT_NOPROGRESS, 1L);
	curl_multi_add_handle(curlMulti_, curlMultiEasy_);
//    res = curl_easy_perform(curl_);
	
    return res;
}
