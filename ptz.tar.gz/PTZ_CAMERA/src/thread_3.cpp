#include "thread_3.h"
#include <unistd.h>

#include <sstream>
#include <iostream>

enum {sleepLoop = 100000};

poster::poster():mutex_(), run(true)
{
    live = false;
    thr = std::thread(&poster::worker, this);
}

poster::~poster()
{
	run = false;
    thr.join();
}

void poster::worker()
{
	while(run)
	{
		bool liveCurr;
		std::string nameCurr;
		std::string dopCurr;
		{
			std::lock_guard<std::mutex> lock(mutex_);
			liveCurr = live;
			nameCurr = name;
			dopCurr = dop;
			
		}
			
		if(liveCurr)
		{
			url = prefixPTZ + "/cgi-bin/configManager.cgi?action=setConfig&ChannelTitle[0].Name=" + dopCurr;
			httpPoster.sendHttpGet(url);
			usleep(sleepLoop);
			url = prefixPTZ + "/cgi-bin/snapshot.cgi";
			fp = fopen(nameCurr.c_str(),"wb");
			httpPoster.sendHttpGet(url, fp);
			fclose(fp);
		}
		live = false;
		usleep(sleepLoop);
	}
}

void poster::posterNow(std::string name_, std::string dop_)
{
	{
	std::lock_guard<std::mutex> lock(mutex_);
	name = name_;
	dop = dop_;
	live = true;	
	}
}
