#ifndef TH_3
#define TH_3

#include <thread>
#include <string>
#include <mutex>

#include "httpApi.h"


class poster
{
public:
    // Constructor & destructor
    poster();
    ~poster();
	void posterNow(std::string name, std::string dop);
	void stop();
	
private:	
	std::thread thr;
	void worker();
	volatile bool live;
	httpApi httpPoster;
	std::string url;
	std::mutex mutex_;
	std::string name;
	std::string dop;
	FILE *fp;
	bool run;
};


#endif