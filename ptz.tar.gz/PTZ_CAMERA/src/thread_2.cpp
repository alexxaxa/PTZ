#include "thread_2.h"
#include <unistd.h>
#include <sstream>
#include <iostream>

saveVideo::saveVideo(std::string prefix)
{
	run = true;
	name = prefix + "/saveFile.jpg";
    thr = std::thread(&saveVideo::worker, this);
}

saveVideo::~saveVideo()
{
	run = false;
    thr.join();
}

bool saveVideo::obmanka(bool ff)
{
	return ff;
}

void saveVideo::worker()
{
	std::string url = prefixPTZ + "/cgi-bin/mjpg/video.cgi";
	std::cout << "save:" << name << std::endl;
	fp = fopen(name.c_str(),"wb");
	httpSave.httpGet(url, fp);
	while(run)
	{
		run = obmanka(run);
		usleep(20000);
	}
	fclose(fp);
}

